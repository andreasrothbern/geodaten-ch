# SVG-Generierung für Gerüstplanung - Prompt-Optimierung

## Übersicht

Dieses Dokument fasst die Erkenntnisse aus der Optimierung der SVG-Generierungs-Prompts für die Gerüstplanung Schweiz App zusammen.

**Ziel:** Technische Architekturzeichnungen (Grundriss, Fassadenansicht, Gebäudeschnitt) für die Gerüstplanung automatisch generieren.

**Stand:** 30. Dezember 2025

---

## 1. Identifizierte Probleme

### 1.1 Datenqualität

| Problem | Beispiel | Auswirkung |
|---------|----------|------------|
| **Falscher Gebäudetyp** | "Wohngebäude" statt "Kirche" | Falsche Architektur-Darstellung |
| **Fehlende Gebäuderecherche** | `RECHERCHIEREN` im Prompt | Sonnet muss Web-Suche machen → langsamer, teurer, unzuverlässig |
| **Falsche Turmkonfiguration** | "Doppelturm" statt "1 Turm" | Architektonisch inkorrekte SVGs |
| **Fehlende Höhenzonen** | Nur 1 Zone für komplexes Gebäude | Turm, Chor, Seitenschiffe fehlen |
| **GWR-Daten unzuverlässig** | Kirche als "Wohngebäude" | Grundlegende Fehlklassifikation |

### 1.2 Prompt-Struktur

| Problem | Auswirkung |
|---------|------------|
| **80% Redundanz** | 3 Prompts mit gleichen Basisdaten → unnötige Token-Kosten |
| **Encoding-Fehler** | UTF-8 Umlaute kaputt (ä → Ã¤) |
| **Keine Validierung** | Inkonsistente Höhenangaben werden nicht erkannt |
| **Zonen-API-Fehler** | Authentication-Fehler → keine automatische Zonen-Erkennung |

### 1.3 SVG-Darstellung

| Problem | Lösung |
|---------|--------|
| **Fassade vs. Schnitt zu ähnlich** | Klare Schraffur-Unterscheidung: `hatch` vs. `cut-hatch` |
| **Innenräume im Schnitt schraffiert** | Explizit: Innenräume = WEISS/LEER |
| **Treppenstufen in Gerüstzone** | Vereinfachte rechteckige Hülle verwenden |
| **Verdeckung fehlt** | Vordere Elemente müssen hintere verdecken |

---

## 2. Optimierter Workflow

```
┌─────────────────────────────────────────────────────────┐
│ 1. EINGABE: EGID / Adresse / Koordinaten                │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│ 2. SERVER-SEITIGE RECHERCHE (vor API-Call!)             │
│                                                         │
│    a) GWR-Daten abrufen (Grundfläche, Baujahr)          │
│    b) Gebäude identifizieren (Name, Typ, Baustil)       │
│    c) Turmkonfiguration klären (Anzahl, Position, Form) │
│    d) Höhenzonen automatisch generieren                 │
│    e) Ergebnisse cachen (Redis/DB)                      │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│ 3. PROMPT GENERIEREN                                    │
│                                                         │
│    a) Basis-Template mit validierten Daten füllen       │
│    b) Höhenzonen einfügen                               │
│    c) SVG-Typ-spezifische Anforderungen hinzufügen      │
│    d) Encoding validieren (UTF-8)                       │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│ 4. CLAUDE API (Sonnet) AUFRUFEN                         │
│                                                         │
│    → Keine Recherche mehr nötig (bereits erledigt)      │
│    → Weniger Tokens (keine Redundanz)                   │
│    → Schneller Response                                 │
│    → Konsistente Ergebnisse                             │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│ 5. SVG VALIDIEREN & SPEICHERN                           │
│                                                         │
│    a) SVG-Syntax validieren                             │
│    b) Höhenskala prüfen                                 │
│    c) Datei speichern / an Client senden                │
└─────────────────────────────────────────────────────────┘
```

---

## 3. Prompt-Template-System

### 3.1 Architektur

```
prompts/
├── base/
│   └── system_prompt.md       # Gemeinsame Basis (1x pro Session)
├── templates/
│   ├── grundriss.md           # SVG 1: Grundriss
│   ├── fassadenansicht.md     # SVG 2: Fassadenansicht
│   └── gebaeudesschnitt.md    # SVG 3: Gebäudeschnitt
└── examples/
    ├── kirche.md              # Beispiel: Neugotische Kirche
    ├── rathaus.md             # Beispiel: Spätgotisches Rathaus
    └── bundeshaus.md          # Beispiel: Neorenaissance-Parlament
```

### 3.2 Token-Einsparung

| Ansatz | Tokens (geschätzt) | Kosten |
|--------|-------------------|--------|
| **Aktuell:** 3 separate Prompts | ~4500 Tokens × 3 = 13'500 | 100% |
| **Optimiert:** Basis + 3 kurze Prompts | ~3000 + 3×500 = 4'500 | 33% |

### 3.3 Variablen-System

```typescript
interface BuildingData {
  // Identifikation
  address: string;
  egid: string;
  coordinates: { e: number; n: number };
  
  // Recherchiert (NICHT mehr RECHERCHIEREN!)
  buildingName: string;
  buildingType: string;
  architecturalStyle: string;
  yearBuilt: number;
  
  // Geometrie
  boundingBox: { length: number; width: number };
  groundArea: number;
  roofHeight: number;
  eaveHeight: number;
  
  // Terrain
  terrainHeight: number;
  isSloped: boolean;
  
  // Höhenzonen (KRITISCH!)
  zones: Zone[];
  
  // Turm (falls vorhanden)
  tower?: {
    count: number;
    position: 'zentral' | 'flankierend' | 'ecke';
    form: 'Spitzhelm' | 'Kuppel' | 'Flachdach';
    height: number;
    scaffoldType: 'Standard' | 'Spezialgerüst';
  };
}

interface Zone {
  name: string;
  type: 'hauptgebaeude' | 'turm' | 'kuppel' | 'anbau' | 'arkade' | 'innenhof';
  height: number;
  eaveHeight?: number;
  isScaffolded: boolean;
  scaffoldType?: 'Standard' | 'Spezialgerüst';
}
```

---

## 4. Höhenzonen-Logik

### 4.1 Automatische Zonen-Erkennung

```typescript
function generateZones(building: BuildingData): Zone[] {
  const zones: Zone[] = [];
  
  // Hauptgebäude immer vorhanden
  zones.push({
    name: 'Hauptgebäude',
    type: 'hauptgebaeude',
    height: building.eaveHeight + 5, // Schätzung
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Turm erkennen (Höhendifferenz > 15m)
  if (building.roofHeight - building.eaveHeight > 15) {
    zones.push({
      name: detectTowerName(building),
      type: 'turm',
      height: building.roofHeight,
      isScaffolded: false,
      scaffoldType: 'Spezialgerüst'
    });
  }
  
  // Kuppel erkennen (bei Parlamenten, Kirchen)
  if (building.architecturalStyle.includes('Renaissance') || 
      building.buildingType.includes('Parlament')) {
    zones.push({
      name: 'Kuppel',
      type: 'kuppel',
      height: building.roofHeight,
      isScaffolded: false,
      scaffoldType: 'Spezialgerüst'
    });
  }
  
  return zones;
}
```

### 4.2 Gebäudetyp-spezifische Zonen

| Gebäudetyp | Typische Zonen |
|------------|----------------|
| **Kirche (Neugotik)** | Hauptschiff, Seitenschiffe, Westturm, Chor |
| **Rathaus (Spätgotik)** | Hauptgebäude, Turm, Arkaden |
| **Bundeshaus** | Westflügel, Ostflügel, Zentralbau, Kuppel, Verbindungsgänge |
| **Wohnhaus (einfach)** | Hauptgebäude |
| **Wohnhaus (mit Erker)** | Hauptgebäude, Erker |

---

## 5. SVG Style-Vorgaben

### 5.1 Schraffur-Patterns

```xml
<defs>
  <!-- LOCKERE Schraffur für Aussenflächen (Fassade, Grundriss) -->
  <pattern id="hatch" patternUnits="userSpaceOnUse" width="8" height="8">
    <path d="M0,0 l8,8" stroke="#999" stroke-width="0.5"/>
  </pattern>

  <!-- DICHTE Schraffur für Schnittflächen (geschnittenes Mauerwerk) -->
  <pattern id="cut-hatch" patternUnits="userSpaceOnUse" width="4" height="4">
    <path d="M0,0 l4,4 M0,4 l4,-4" stroke="#666" stroke-width="0.8"/>
  </pattern>

  <!-- Terrain/Boden -->
  <pattern id="ground" patternUnits="userSpaceOnUse" width="20" height="10">
    <path d="M0,10 L10,0 M10,10 L20,0" stroke="#666" stroke-width="0.5"/>
  </pattern>

  <!-- Kupfer-Gradient NUR für Kuppeln -->
  <linearGradient id="copper" x1="0%" y1="0%" x2="0%" y2="100%">
    <stop offset="0%" style="stop-color:#7CB9A5"/>
    <stop offset="100%" style="stop-color:#4A8A77"/>
  </linearGradient>
  
  <!-- Gerüstzone -->
  <pattern id="scaffold-zone" patternUnits="userSpaceOnUse" width="10" height="10">
    <rect width="10" height="10" fill="#FFEE88" fill-opacity="0.3"/>
  </pattern>
</defs>
```

### 5.2 Farb-Palette

| Element | Farbe/Fill | Hex-Code |
|---------|------------|----------|
| Hintergrund | Weiss | `#FFFFFF` |
| Gebäude-Aussenfläche | Lockere Schraffur | `url(#hatch)` |
| Schnittfläche (Mauerwerk) | Dichte Schraffur | `url(#cut-hatch)` |
| Innenraum (im Schnitt) | Weiss/LEER | `#FFFFFF` |
| Kuppel | Kupfer-Gradient | `url(#copper)` |
| Gerüst-Ständer | Blau | `#0066CC` |
| Gerüst-Beläge | Braun | `#8B4513` |
| Verankerungen | Rot gestrichelt | `#CC0000` |
| Gerüstzone | Gelb transparent | `#FFEE88` (30%) |

### 5.3 Kritische Unterscheidung: Fassade vs. Schnitt

```
FASSADENANSICHT                    GEBÄUDESCHNITT
================                    ===============
Blick von AUSSEN                   Blick in SCHNITTEBENE

    ┌─────────┐                        ┌─────────┐
    │░░░░░░░░░│ ← Fassade             │█│     │█│ ← Schnittfläche
    │░░░░░░░░░│   (alles sichtbar      │ │     │ │   (dicht schraffiert)
    │░░░░░░░░░│    von aussen)         │ │     │ │
    └─────────┘                        │ │     │ │ ← Innenraum (LEER!)
                                       └─┴─────┴─┘

░░░ = lockere Schraffur            █ = dichte Schnitt-Schraffur
      url(#hatch)                       url(#cut-hatch)
                                     = weiss (Innenraum)
```

---

## 6. Beispiel: St. Peter und Paul, Bern

### 6.1 Recherche-Ergebnis

```yaml
Gebäude:
  Name: "Kirche St. Peter und Paul"
  Typ: "Christkatholische Kathedralkirche"
  Baustil: "Dogmatische Neugotik"
  Baujahr: 1864
  Architekt: "Pierre Joseph Edouard Deperthes"
  
Turm:
  Anzahl: 1  # WICHTIG: NICHT 2!
  Position: "zentral (Westturm)"
  Form: "Spitzhelm"
  Höhe: 54.6m
  
Besonderheiten:
  - Dreischiffige Basilika
  - Kreuzrippengewölbe
  - Grösste Krypta der Schweiz
  - Spitzbogenfenster
  - Rosettenfenster
```

### 6.2 Korrekte Höhenzonen

```markdown
| Zone | Typ | Höhe | Traufe | Eingerüstet |
|------|-----|------|--------|-------------|
| Kirchenschiff | hauptgebaeude | 25m | 18m | Ja |
| Westturm | turm | 54.6m | 20m | Nein [Spezialgerüst] |
| Chor | anbau | 18m | 12m | Ja |
```

### 6.3 Häufiger Fehler

❌ **FALSCH:** "Westfassade_Doppeltürme" → 2 Türme
✅ **KORREKT:** 1 zentraler Westturm mit Spitzhelm

---

## 7. API-Integration

### 7.1 Server-seitige Recherche

```typescript
async function researchBuilding(egid: string, address: string): Promise<BuildingData> {
  // 1. Cache prüfen
  const cached = await redis.get(`building:${egid}`);
  if (cached) return JSON.parse(cached);
  
  // 2. GWR-Daten abrufen
  const gwrData = await fetchGWR(egid);
  
  // 3. Gebäude identifizieren (Wikipedia, Denkmalpflege, etc.)
  const buildingInfo = await identifyBuilding(address, egid);
  
  // 4. Höhenzonen generieren
  const zones = generateZones(buildingInfo, gwrData);
  
  // 5. Zusammenführen und cachen
  const result: BuildingData = {
    ...gwrData,
    ...buildingInfo,
    zones
  };
  
  await redis.setex(`building:${egid}`, 86400, JSON.stringify(result));
  return result;
}
```

### 7.2 Prompt-Generierung

```typescript
function generatePrompt(
  building: BuildingData, 
  svgType: 'grundriss' | 'fassadenansicht' | 'gebaeudesschnitt'
): string {
  // Basis-Template laden
  const baseTemplate = loadTemplate('base/building_data.md');
  
  // Mit Daten füllen
  const filledBase = fillTemplate(baseTemplate, building);
  
  // SVG-spezifisches Template
  const svgTemplate = loadTemplate(`templates/${svgType}.md`);
  
  // Kombinieren
  return `${filledBase}\n\n${svgTemplate}`;
}
```

### 7.3 Claude API Aufruf

```typescript
async function generateSVG(
  building: BuildingData,
  svgType: 'grundriss' | 'fassadenansicht' | 'gebaeudesschnitt'
): Promise<string> {
  const prompt = generatePrompt(building, svgType);
  
  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 8000,
    messages: [
      {
        role: 'user',
        content: prompt
      }
    ]
  });
  
  // SVG aus Response extrahieren
  const svg = extractSVG(response.content[0].text);
  
  // Validieren
  validateSVG(svg);
  
  return svg;
}
```

---

## 8. Checkliste für neue Gebäude

### 8.1 Vor dem API-Call

- [ ] EGID validiert
- [ ] Gebäudename recherchiert (nicht "RECHERCHIEREN")
- [ ] Gebäudetyp korrekt (nicht aus GWR übernehmen!)
- [ ] Baustil ermittelt
- [ ] Turmkonfiguration geklärt (Anzahl, Position, Form)
- [ ] Höhenzonen definiert
- [ ] Spezialgerüst-Zonen markiert
- [ ] Encoding validiert (UTF-8)

### 8.2 Nach dem API-Call

- [ ] SVG-Syntax gültig
- [ ] Höhenskala korrekt
- [ ] Schraffuren korrekt (Fassade ≠ Schnitt)
- [ ] Turm richtig dargestellt
- [ ] Innenräume im Schnitt LEER
- [ ] Gerüst nur an eingerüsteten Zonen

---

## 9. Dateien in diesem Paket

```
svg_prompt_optimization/
├── README.md                          # Diese Dokumentation
├── templates/
│   ├── system_prompt.md               # Gemeinsame Basis
│   ├── grundriss.md                   # SVG 1 Template
│   ├── fassadenansicht.md             # SVG 2 Template
│   └── gebaeudesschnitt.md            # SVG 3 Template
├── examples/
│   ├── st_peter_paul_bern.md          # Beispiel: Neugotische Kirche
│   └── bundeshaus_bern.md             # Beispiel: Parlamentsgebäude
└── code/
    ├── types.ts                       # TypeScript Interfaces
    ├── zone_generator.ts              # Höhenzonen-Logik
    └── prompt_builder.ts              # Prompt-Generierung
```

---

## 10. Kontakt & Weiterentwicklung

**Generiert mit:** Claude (Anthropic)
**Datum:** 30. Dezember 2025
**App:** Gerüstplanung Schweiz v3.0

Bei Fragen oder Verbesserungsvorschlägen: Issues im Repository erstellen.

---

*Dieses Dokument ist Teil der Gerüstplanung Schweiz App und dokumentiert die Optimierung der SVG-Generierungs-Prompts für die Claude API.*
