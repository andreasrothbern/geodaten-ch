# SVG-Anforderung: Grundriss (Draufsicht)

## Gebäudedaten

{{BUILDING_DATA}}

## Anforderungen

Erstelle einen **Grundriss** (Vogelperspektive) mit folgenden Elementen:

### Perspektive
- Blick von oben (Draufsicht)
- Norden = oben

### Gebäudedarstellung
- Vereinfachte Form basierend auf Bounding-Box und Gebäudetyp
- Mauern mit `url(#hatch)` schraffiert
- Wandstärke andeuten (~0.5-1m)
- Zonen farblich/durch Beschriftung unterscheiden

### Gerüstzone
- Rechteckige Hülle mit 1m Abstand um Gebäude
- `url(#scaffold-zone)` als Fill
- Gestrichelter gelber Rand (`#FFD700`)
- **KEINE Treppenstufen** bei komplexen Polygonen!

### Gerüst-Elemente
- Ständer als kleine blaue Quadrate (`#0066CC`)
- Verankerungen als gestrichelte rote Kreise (`#CC0000`)

### Beschriftungen
- Fassadenlängen pro Seite
- Himmelsrichtungen (N, O, S, W)
- Zonen-Namen und Höhen
- "[eingerüstet]" bei eingerüsteten Zonen
- "[Spezialgerüst]" bei Türmen/Kuppeln

### Pflicht-Elemente
- **Nordpfeil:** Unten rechts, Kreis mit Pfeil nach oben, "N"
- **Massstab:** Unten links, Linie mit 0/10m/20m Beschriftung
- **Legende:** Unten, erklärt Symbole
- **Titel:** Oben, Gebäudename + Adresse

### Spezielle Gebäudetypen

**Kirche (Basilika):**
```
    ┌───────────┐
    │   TURM    │
    ├───────────┤
    │ HAUPTSCH. │
┌───┤           ├───┐
│ S │           │ S │  (S = Seitenschiff)
└───┴─────┬─────┴───┘
          │ CHOR │
          └──────┘
```

**Bundeshaus (H-Form):**
```
┌─────┐     ┌─────┐
│WEST │─────│ OST │
│FLÜG.│     │FLÜG.│
├─────┤     ├─────┤
│     │ZENTR│     │
│     │(◯)  │     │  (◯ = Kuppel)
├─────┤     ├─────┤
│     │─────│     │
└─────┘     └─────┘
```

## Output

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 480">
  <defs>
    <!-- Pattern-Definitionen hier -->
  </defs>
  
  <!-- Hintergrund -->
  <rect width="700" height="480" fill="#FFFFFF"/>
  
  <!-- Titel -->
  <!-- Gerüstzone -->
  <!-- Gebäude -->
  <!-- Zonen-Beschriftungen -->
  <!-- Gerüst-Elemente -->
  <!-- Nordpfeil -->
  <!-- Massstab -->
  <!-- Legende -->
</svg>
```

**NUR SVG-Code ausgeben, keine Erklärungen.**
