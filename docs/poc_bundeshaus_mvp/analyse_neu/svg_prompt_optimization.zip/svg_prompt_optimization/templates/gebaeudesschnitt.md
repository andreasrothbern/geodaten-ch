# SVG-Anforderung: Gebäudeschnitt (Querschnitt)

## Gebäudedaten

{{BUILDING_DATA}}

## Anforderungen

Erstelle einen **Gebäudeschnitt** (Querschnitt entlang Linie A-A) mit folgenden Elementen:

### Perspektive
- Gebäude AUFGESCHNITTEN
- Blick in die Schnittebene
- Zeigt Innenräume und Konstruktion

### KRITISCHE Schraffur-Regel

| Element | Schraffur | Begründung |
|---------|-----------|------------|
| Geschnittene Mauern | `url(#cut-hatch)` DICHT | Mauerwerk im Schnitt |
| Innenräume | `#FFFFFF` LEER | Luft/Raum |
| Geschossdecken | `url(#cut-hatch)` DICHT | Beton/Holz im Schnitt |
| Terrain | `url(#ground)` | Erdreich |

### WICHTIG - Innenräume sind LEER

```
FALSCH ❌                          RICHTIG ✅
┌─────────────────┐                ┌─────────────────┐
│█████████████████│                │█│             │█│
│█████████████████│                │ │             │ │
│█████████████████│                │ │   (leer)   │ │
│█████████████████│                │ │             │ │
└─────────────────┘                └─┴─────────────┴─┘
  Alles schraffiert                  Nur Wände schraffiert
```

### Gebäudedarstellung
- Aussenwände: Dick, `url(#cut-hatch)`
- Innenwände: Dünner, `url(#cut-hatch)`
- Innenräume: WEISS (#FFFFFF), keine Schraffur!
- Geschossdecken: Horizontale Linien, `url(#cut-hatch)`
- Dachkonstruktion: Sichtbar, `url(#cut-hatch)`

### Sichtbare Elemente im Schnitt
- Raumhöhen
- Geschosse (EG, OG, DG)
- Gewölbe/Decken (bei Kirchen: Kreuzrippengewölbe)
- Keller/Krypta (falls vorhanden)
- Dachstuhl
- Turm-Innenraum

### Kuppel (falls vorhanden)
- Doppelschale zeigen (Innen- und Aussenschale)
- Aussenschale: `url(#copper)`
- Zwischenraum: WEISS
- Laterne oben

### Terrain-Linie
- Horizontale Linie bei ±0.00
- Darunter: `url(#ground)` Pattern für Erdreich
- Beschriftung: "±0.00 = XXX.X m ü.M."

### Höhenskala (links)
- Vertikale Linie mit Markierungen
- ±0.00, Geschosshöhen, First
- Bei Kirchen: Gewölbehöhe

### Schnittmarkierung A-A
- Links und rechts am Rand
- Roter Text "A" mit gestrichelter Linie

### Gerüst
- Links UND rechts des Gebäudes
- Nur an eingerüsteten Zonen
- **Ständer:** Vertikale blaue Linien (`#0066CC`)
- **Beläge:** Horizontale braune Linien (`#8B4513`)
- **Verankerungen:** Rote gestrichelte Linien zur Wand

### Raumbezeichnungen
- Im LEEREN Innenraum platzieren
- Z.B. "EG", "1.OG", "Hauptschiff", "Kuppelraum"
- Kleine Schrift, grau (#999)

### Pflicht-Elemente
- **Titel:** Oben, Gebäudename + "Schnitt A-A"
- **Schnittmarkierung:** A-A links und rechts
- **Legende:** Unten, erklärt Schraffuren und Gerüst

## Beispiel-Struktur für Kirche

```
                      ╱╲
                     ╱  ╲ ← Spitzhelm
                    ┌────┐
                    │█  █│ ← Turm (Wände = cut-hatch)
                    │    │   (Innen = leer)
        ┌───────────┤    ├───────────┐
        │█│         │    │         │█│
        │ │  ╭───╮  │    │  ╭───╮  │ │ ← Gewölbe sichtbar
        │ │  │   │  │    │  │   │  │ │
┌───────┤ ├──┤   ├──┤    ├──┤   ├──┤ ├───────┐
│█│     │ │  │   │  │    │  │   │  │ │     │█│
│ │SEIT.│ │  │HAU│  │TURM│  │HAU│  │ │SEIT.│ │
│ │     │ │  │PT │  │    │  │PT │  │ │     │ │
└─┴─────┴─┴──┴───┴──┴────┴──┴───┴──┴─┴─────┴─┘
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ← Terrain (url(#ground))
```

## Output

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 480">
  <defs>
    <!-- Pattern-Definitionen hier -->
  </defs>
  
  <!-- Hintergrund -->
  <rect width="700" height="480" fill="#FFFFFF"/>
  
  <!-- Titel -->
  <!-- Terrain-Linie + Erdreich -->
  <!-- Höhenskala links -->
  <!-- Gebäude-Schnitt (Wände = cut-hatch, Innen = leer!) -->
  <!-- Geschossdecken -->
  <!-- Raumbezeichnungen -->
  <!-- Gerüst links -->
  <!-- Gerüst rechts -->
  <!-- Schnittmarkierung A-A -->
  <!-- Lagenbeschriftung rechts -->
  <!-- Legende -->
</svg>
```

**NUR SVG-Code ausgeben, keine Erklärungen.**
