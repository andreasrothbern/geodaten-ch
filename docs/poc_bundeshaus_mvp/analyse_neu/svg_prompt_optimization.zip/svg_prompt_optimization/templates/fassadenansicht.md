# SVG-Anforderung: Fassadenansicht (Elevation)

## Gebäudedaten

{{BUILDING_DATA}}

## Anforderungen

Erstelle eine **Fassadenansicht** (Frontalansicht von aussen) mit folgenden Elementen:

### Perspektive
- Orthogonale 2D-Ansicht
- Blick von AUSSEN auf die Hauptfassade
- **Verdeckungsregel:** Vordere Elemente verdecken hintere!

### Gebäudedarstellung
- Alle sichtbaren Aussenflächen mit `url(#hatch)` schraffiert
- Verschiedene Höhenzonen darstellen
- Baustil-typische Elemente zeigen:
  - Fenster (als weisse Rechtecke/Bögen)
  - Portal/Eingang
  - Dachform (Satteldach, Walmdach, etc.)
  - Gesimse, Pilaster, Verzierungen

### WICHTIG - Was NICHT sichtbar sein darf
- ❌ Innenräume
- ❌ Gewölbe (nur von aussen erkennbare Dachform)
- ❌ Hintere Gebäudeteile (werden von vorderen verdeckt)

### Höhenzonen
- Jede Zone mit korrekter Höhe darstellen
- Unterschiedliche Dachhöhen berücksichtigen
- Türme/Kuppeln als höchste Elemente

### Kuppel (falls vorhanden)
- Halbkreis-Form
- **Einziger Gradient:** `url(#copper)`
- Mit Laterne und Spitze

### Terrain-Linie
- Horizontale Linie bei ±0.00
- Position: unteres Drittel des SVG
- Beschriftung: "±0.00 = XXX.X m ü.M."

### Höhenskala (links)
- Vertikale Linie mit Markierungen
- ±0.00, Traufhöhe, Firsthöhe
- Zwischenwerte bei grossen Gebäuden

### Lagenbeschriftung (rechts)
- EG, 1.OG, 2.OG, etc.
- Dach, Turm, Kuppel

### Gerüst
- VOR der Fassade (nicht dahinter!)
- Nur an eingerüsteten Zonen
- **Ständer:** Vertikale blaue Linien (`#0066CC`)
- **Beläge:** Horizontale braune Linien (`#8B4513`)
- **Diagonalen:** Dünne blaue X-Linien
- **Verankerungen:** Rote gestrichelte Kreise zur Fassade

### Zonen-Labels
- Name und Höhe jeder Zone
- "[Spezialgerüst]" bei Türmen/Kuppeln

### Pflicht-Elemente
- **Titel:** Oben, Gebäudename + Adresse + Fassade (z.B. "Westfassade")
- **Legende:** Unten, erklärt Gerüst-Symbole

## Beispiel-Struktur für Kirche

```
                    ╱╲
                   ╱  ╲
                  ╱    ╲ ← Spitzhelm (Turm)
                 ┌──────┐
                 │      │
                 │ TURM │ ← Verdeckt Hauptschiff!
                 │      │
        ┌────────┴──────┴────────┐
        │░░░░░░░░░░░░░░░░░░░░░░░░│ ← Hauptschiff (url(#hatch))
        │░░░░░░░░░░░░░░░░░░░░░░░░│
┌───────┤░░░░░░░░░░░░░░░░░░░░░░░░├───────┐
│░░░░░░░│░░░░░░░░░░░░░░░░░░░░░░░░│░░░░░░░│
│ SEIT. │          ⌂⌂⌂           │ SEIT. │ ← Seitenschiffe
│░░░░░░░│░░░░░░░░░░░░░░░░░░░░░░░░│░░░░░░░│
└───────┴────────────────────────┴───────┘
════════════════════════════════════════════ ← Terrain-Linie
```

## Output

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 480">
  <defs>
    <!-- Pattern-Definitionen hier -->
  </defs>
  
  <!-- Hintergrund -->
  <rect width="700" height="480" fill="#FFFFFF"/>
  
  <!-- Titel -->
  <!-- Terrain-Linie -->
  <!-- Höhenskala links -->
  <!-- Gebäude (von hinten nach vorne!) -->
  <!-- Gerüst -->
  <!-- Zonen-Labels -->
  <!-- Lagenbeschriftung rechts -->
  <!-- Legende -->
</svg>
```

**NUR SVG-Code ausgeben, keine Erklärungen.**
