# Beispiel: St. Peter und Paul, Bern

Dieses Beispiel zeigt, wie ein vollständig recherchiertes Prompt aussehen sollte.

## Gebäudedaten (für {{BUILDING_DATA}})

```markdown
## Gebäude-Identifikation

- **Adresse:** Rathausgasse 2, 3011 Bern
- **EGID:** 191821074
- **Koordinaten (LV95):** E 601009, N 199736
- **Gebäudename:** Kirche St. Peter und Paul
- **Gebäudetyp:** Christkatholische Kathedralkirche
- **Baustil:** Dogmatische Neugotik
- **Baujahr:** 1864
- **Architekt:** Pierre Joseph Edouard Deperthes (Reims)
- **Komplexität:** KOMPLEX

## Geometrische Basisdaten

### Dimensionen
- **Bounding Box:** 48m × 29m
- **Grundfläche:** 1099 m²
- **Firsthöhe:** 54.6 m (Turmspitze)
- **Traufhöhe Hauptschiff:** 18 m

### Terrain
- **Terrain-Höhe:** 533.5 m ü.M.
- **Referenzpunkt:** Haupteingang = ±0.00
- **Hanglage:** Nein (eben)

## Höhenzonen

| Zone | Typ | Höhe | Traufe | Eingerüstet |
|------|-----|------|--------|-------------|
| Kirchenschiff | hauptgebaeude | 25m | 18m | Ja |
| Seitenschiff Nord | anbau | 15m | 10m | Ja |
| Seitenschiff Süd | anbau | 15m | 10m | Ja |
| Westturm | turm | 54.6m | 20m | Nein [Spezialgerüst] |
| Chor | anbau | 18m | 12m | Ja |

## Turmkonfiguration

- **Anzahl:** 1 (NICHT 2!)
- **Position:** Zentral (Westfassade)
- **Form:** Spitzhelm (pyramidal)
- **Höhe:** 54.6 m

## Baustil-Merkmale

- **Bauform:** Dreischiffige Basilika, gewestet
- **Fenster:** Spitzbogenfenster
- **Portal:** Neugotisches Hauptportal mit Wimperg
- **Rosette:** Fensterrosette über Portal
- **Gewölbe:** Kreuzrippengewölbe
- **Besonderheit:** Grösste Krypta der Schweiz (unter Hauptschiff)
- **Material:** Sandstein

## Gerüst

### Eingerüstete Zonen
- Kirchenschiff (Nord-, Süd-, Ostfassade)
- Seitenschiffe
- Chor

### Spezialgerüst erforderlich
- Westturm (zu hoch für Standardgerüst)
```

## Verwendung

### Für Grundriss:
```
[System Prompt: system_prompt.md]
[Template: grundriss.md mit obigen Gebäudedaten]
```

### Für Fassadenansicht:
```
[System Prompt: system_prompt.md]
[Template: fassadenansicht.md mit obigen Gebäudedaten]
```

### Für Gebäudeschnitt:
```
[System Prompt: system_prompt.md]
[Template: gebaeudesschnitt.md mit obigen Gebäudedaten]
```

## Erwartete Darstellung

### Grundriss
```
         ┌─────────┐
         │  TURM   │
         │ (54.6m) │
    ┌────┴─────────┴────┐
    │                   │
┌───┤   HAUPTSCHIFF     ├───┐
│ N │      (25m)        │ S │
│   │                   │   │
└───┴───────┬───────────┴───┘
            │   CHOR    │
            │  (18m)    │
            └───────────┘
```

### Fassadenansicht (West)
```
              /\
             /  \     ← Spitzhelm
            /    \
           ┌──────┐
           │      │   ← Turm (54.6m)
           │ ⌂⌂⌂  │      Rosette
           │      │
           │ ▮▮▮  │   ← Portal
      ─────┴──────┴─────
```

### Gebäudeschnitt
```
              /\
             /  \
           ┌─┴──┴─┐
           │█│  │█│   ← Turm (Wände = cut-hatch)
           │ │  │ │      (Innen = leer)
     ┌─────┤ │  │ ├─────┐
     │█│   │ │  │ │   │█│
     │ ╲___╱ │  │ ╲___╱ │ ← Gewölbe
     │       │  │       │
     └─┴─────┴──┴─────┴─┘
     ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ← Krypta
```

## Häufige Fehler vermeiden

| Fehler | Korrekt |
|--------|---------|
| ❌ "Doppelturm" / 2 Türme | ✅ 1 zentraler Westturm |
| ❌ Gebäudetyp "Wohngebäude" | ✅ Christkatholische Kathedralkirche |
| ❌ Nur 1 Höhenzone | ✅ 5 Zonen (Hauptschiff, Seitenschiffe, Turm, Chor) |
| ❌ Innenräume schraffiert | ✅ Innenräume WEISS/LEER |
| ❌ Treppenstufen in Gerüstzone | ✅ Rechteckige Hülle |
