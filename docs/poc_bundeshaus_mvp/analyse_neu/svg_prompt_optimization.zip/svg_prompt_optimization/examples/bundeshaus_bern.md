# Beispiel: Bundeshaus, Bern

Dieses Beispiel zeigt ein komplexes Parlamentsgebäude mit Kuppel.

## Gebäudedaten (für {{BUILDING_DATA}})

```markdown
## Gebäude-Identifikation

- **Adresse:** Bundesplatz 3, 3011 Bern
- **EGID:** 2242547
- **Koordinaten (LV95):** E 600423, N 199521
- **Gebäudename:** Bundeshaus (Parlamentsgebäude)
- **Gebäudetyp:** Parlamentsgebäude
- **Baustil:** Neorenaissance
- **Baujahr:** 1902
- **Architekt:** Hans Wilhelm Auer
- **Komplexität:** KOMPLEX

## Geometrische Basisdaten

### Dimensionen
- **Bounding Box:** 80m × 71m
- **Grundfläche:** 3697 m²
- **Kuppelhöhe:** 64 m
- **Traufhöhe Flügel:** 25-30 m

### Terrain
- **Terrain-Höhe:** 543.1 m ü.M.
- **Referenzpunkt:** Haupteingang = ±0.00
- **Hanglage:** Nein (eben)

## Höhenzonen

| Zone | Typ | Höhe | Traufe | Eingerüstet |
|------|-----|------|--------|-------------|
| Hauptgebäude West | hauptgebaeude | 30m | 25m | Ja |
| Hauptgebäude Ost | hauptgebaeude | 30m | 25m | Ja |
| Verbindungsgang West | verbindung | 25m | 20m | Ja |
| Verbindungsgang Ost | verbindung | 25m | 20m | Ja |
| Zentralbau | hauptgebaeude | 30m | 25m | Ja |
| Kuppel | kuppel | 64m | - | Nein [Spezialgerüst] |

## Kuppelkonfiguration

- **Anzahl:** 1
- **Position:** Zentral (über Zentralbau)
- **Form:** Kuppel mit Tambour und Laterne
- **Höhe:** 64 m
- **Material:** Kupfer (grün patiniert)
- **Darstellung:** `url(#copper)` Gradient

## Baustil-Merkmale

- **Bauform:** Symmetrische H-Form mit Flügelbauten
- **Fassade:** Monumentaler Sandstein, Neorenaissance
- **Portal:** Säulenportikus mit korinthischen Säulen
- **Freitreppe:** Repräsentative Treppe vor Portikus
- **Kolonnaden:** Arkadengänge in Verbindungsflügeln
- **Skulpturen:** Allegorische Figuren, Reliefs
- **Innenhöfe:** 4 Innenhöfe zwischen Flügeln

## Gerüst

### Eingerüstete Zonen
- Hauptgebäude West
- Hauptgebäude Ost
- Verbindungsgang West
- Verbindungsgang Ost
- Zentralbau (Basis)

### Spezialgerüst erforderlich
- Kuppel (Spezialkonstruktion für Rundung)
```

## Erwartete Darstellung

### Grundriss (H-Form)
```
┌───────┐           ┌───────┐
│ WEST  │───────────│  OST  │
│FLÜGEL │   VERB.   │FLÜGEL │
│ (30m) │   (25m)   │ (30m) │
├───────┤           ├───────┤
│       │  ZENTRAL  │       │
│       │    ◯      │       │  ◯ = Kuppel (64m)
│       │  (30m)    │       │
├───────┤           ├───────┤
│       │   VERB.   │       │
│       │   (25m)   │       │
└───────┘───────────└───────┘
```

### Fassadenansicht (Nord/Bundesplatz)
```
                    ╱══╲
                   ╱    ╲        ← Kuppel (url(#copper))
                  ╱  ◯   ╲
                 ┌────────┐
                 │ TAMBOUR│
                 │        │
        ┌────────┴────────┴────────┐
        │░░░░░ ZENTRALBAU ░░░░░░░░░│
        │░░░░░░░░░░░░░░░░░░░░░░░░░░│
┌───────┤░░░░░ PORTIKUS ░░░░░░░░░░├───────┐
│░WEST░░│░░░░░ ▌▌▌▌▌ ░░░░░░░░░░░░│░░OST░░│
│░FLÜG.░│░░░░░░░░░░░░░░░░░░░░░░░░│░FLÜG.░│
│░░░░░░░│░░░░░░░░░░░░░░░░░░░░░░░░│░░░░░░░│
└───────┴────────────────────────┴───────┘
════════════════════════════════════════════
```

### Gebäudeschnitt
```
                    ╱══╲
                   ╱    ╲
                  │  ◯   │   ← Kuppelraum (LEER!)
                 ┌┴──────┴┐
                 │█│    │█│  ← Tambour (Wände = cut-hatch)
                 │ │    │ │
        ┌────────┤ │    │ ├────────┐
        │█│      │ │    │ │      │█│
        │ │ WEST │ │ZENT│ │ OST  │ │
        │ │      │ │    │ │      │ │
        └─┴──────┴─┴────┴─┴──────┴─┘
        ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
```

## Besonderheiten

### Kuppel-Darstellung
- **Grundriss:** Kreis mit `url(#copper)` Fill
- **Fassade:** Halbkreis mit `url(#copper)` Fill, Laterne oben
- **Schnitt:** Doppelschale (Aussen: copper, Innen: Kontur), Kuppelraum LEER

### Portikus
- **Fassade:** Giebel über Säulen, Säulen als weisse Rechtecke
- **Schnitt:** Säulen im Schnitt sichtbar (cut-hatch)

### Verbindungsgänge
- Niedriger als Hauptgebäude (25m vs 30m)
- Mit Arkaden im EG

## Häufige Fehler vermeiden

| Fehler | Korrekt |
|--------|---------|
| ❌ Kuppel als "turm" Typ | ✅ Kuppel als "kuppel" Typ mit `url(#copper)` |
| ❌ Alle Zonen gleiche Höhe | ✅ West/Ost 30m, Verbindung 25m, Kuppel 64m |
| ❌ Kuppel vollflächig schraffiert | ✅ Kuppel mit Gradient, Innenraum LEER |
| ❌ Portikus fehlt | ✅ Säulenportikus mit Giebel darstellen |
| ❌ Symmetrie verletzt | ✅ Exakt symmetrische H-Form |
