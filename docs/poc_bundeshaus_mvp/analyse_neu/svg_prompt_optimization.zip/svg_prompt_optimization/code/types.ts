/**
 * TypeScript Interfaces für SVG-Generierung
 * Gerüstplanung Schweiz App
 */

// ============================================
// Gebäude-Identifikation
// ============================================

export interface BuildingIdentification {
  /** Vollständige Adresse */
  address: string;
  
  /** Eidgenössischer Gebäudeidentifikator */
  egid: string;
  
  /** Koordinaten im LV95-System */
  coordinates: {
    e: number; // Ost
    n: number; // Nord
  };
  
  /** Recherchierter Gebäudename (NICHT "RECHERCHIEREN"!) */
  buildingName: string;
  
  /** Gebäudetyp (Kirche, Rathaus, Wohnhaus, etc.) */
  buildingType: BuildingType;
  
  /** Architektonischer Baustil */
  architecturalStyle: ArchitecturalStyle;
  
  /** Baujahr */
  yearBuilt: number;
  
  /** Architekt (falls bekannt) */
  architect?: string;
  
  /** Komplexitätsstufe */
  complexity: 'SIMPLE' | 'COMPLEX';
}

export type BuildingType = 
  | 'Kirche'
  | 'Kathedrale'
  | 'Rathaus'
  | 'Parlamentsgebäude'
  | 'Wohnhaus'
  | 'Geschäftshaus'
  | 'Schulhaus'
  | 'Museum'
  | 'Theater'
  | 'Bahnhof'
  | 'Andere';

export type ArchitecturalStyle =
  | 'Romanik'
  | 'Gotik'
  | 'Spätgotik'
  | 'Neugotik'
  | 'Renaissance'
  | 'Neorenaissance'
  | 'Barock'
  | 'Klassizismus'
  | 'Historismus'
  | 'Jugendstil'
  | 'Moderne'
  | 'Postmoderne'
  | 'Standard';

// ============================================
// Geometrische Basisdaten
// ============================================

export interface GeometricData {
  /** Bounding Box */
  boundingBox: {
    length: number; // O-W Ausdehnung in Metern
    width: number;  // N-S Ausdehnung in Metern
  };
  
  /** Grundfläche in m² */
  groundArea: number;
  
  /** Firsthöhe (höchster Punkt) in Metern */
  roofHeight: number;
  
  /** Traufhöhe (Dachrand) in Metern */
  eaveHeight: number;
  
  /** Anzahl Geschosse (optional) */
  floors?: number;
  
  /** Polygon-Komplexität */
  polygonPoints: number;
  
  /** Umfang in Metern */
  perimeter: number;
}

// ============================================
// Terrain
// ============================================

export interface TerrainData {
  /** Terrain-Höhe über Meer */
  terrainHeight: number;
  
  /** Referenzpunkt (±0.00) */
  referencePoint: string;
  
  /** Hanglage? */
  isSloped: boolean;
  
  /** Maximale Höhendifferenz (bei Hanglage) */
  maxHeightDifference?: number;
}

// ============================================
// Dach-Analyse
// ============================================

export interface RoofData {
  /** Dachform */
  roofType: RoofType;
  
  /** Dachneigung in Grad */
  roofPitch: number;
  
  /** First-Ausrichtung */
  ridgeOrientation: 'N-S' | 'O-W' | 'NE-SW' | 'NW-SE';
  
  /** Konfidenz der Analyse (0-100%) */
  confidence: number;
}

export type RoofType =
  | 'satteldach'
  | 'walmdach'
  | 'mansarddach'
  | 'pultdach'
  | 'flachdach'
  | 'kuppel'
  | 'spitzhelm'
  | 'zeltdach';

// ============================================
// Höhenzonen (KRITISCH!)
// ============================================

export interface HeightZone {
  /** Name der Zone */
  name: string;
  
  /** Zonen-Typ */
  type: ZoneType;
  
  /** Maximale Höhe der Zone in Metern */
  height: number;
  
  /** Traufhöhe (optional) */
  eaveHeight?: number;
  
  /** Wird diese Zone eingerüstet? */
  isScaffolded: boolean;
  
  /** Art des Gerüsts */
  scaffoldType: 'Standard' | 'Spezialgerüst';
  
  /** Begründung für Spezialgerüst */
  scaffoldReason?: string;
}

export type ZoneType =
  | 'hauptgebaeude'  // Rechteckiger Hauptkörper
  | 'turm'           // Schmaler, hoher Turm
  | 'kuppel'         // Kuppel mit Gradient
  | 'anbau'          // Niedrigerer Anbau
  | 'arkade'         // Rundbogen im EG
  | 'innenhof'       // Freifläche (nicht einrüsten)
  | 'verbindung';    // Verbindungsgang

// ============================================
// Turmkonfiguration
// ============================================

export interface TowerConfiguration {
  /** Anzahl der Türme */
  count: number;
  
  /** Position des/der Türme */
  position: 'zentral' | 'flankierend' | 'ecke' | 'seitlich';
  
  /** Form des Turmabschlusses */
  form: 'Spitzhelm' | 'Kuppel' | 'Flachdach' | 'Pyramide' | 'Zwiebelturm';
  
  /** Höhe des höchsten Turms */
  height: number;
  
  /** Gerüsttyp */
  scaffoldType: 'Standard' | 'Spezialgerüst';
}

// ============================================
// Baustil-Merkmale
// ============================================

export interface StyleFeatures {
  /** Bauform (z.B. "Dreischiffige Basilika") */
  buildingForm?: string;
  
  /** Fenstertyp */
  windowType?: 'Spitzbogen' | 'Rundbogen' | 'Rechteck' | 'Rosette';
  
  /** Portal-Beschreibung */
  portal?: string;
  
  /** Besondere Elemente */
  specialElements: string[];
  
  /** Material */
  material?: string;
}

// ============================================
// Fassaden
// ============================================

export interface Facade {
  /** Fassaden-Index */
  index: number;
  
  /** Länge in Metern */
  length: number;
  
  /** Himmelsrichtung */
  direction: 'N' | 'NO' | 'O' | 'SO' | 'S' | 'SW' | 'W' | 'NW';
}

// ============================================
// Gerüst-Zugänge (SUVA)
// ============================================

export interface ScaffoldAccess {
  /** Zugangs-ID */
  id: string;
  
  /** Fassaden-Richtung */
  facade: string;
  
  /** Position entlang Fassade (0-100%) */
  position: number;
  
  /** SUVA-konform? */
  isSuvaCompliant: boolean;
  
  /** Grund (falls nicht konform) */
  reason?: string;
}

// ============================================
// Vollständige Gebäudedaten
// ============================================

export interface BuildingData {
  identification: BuildingIdentification;
  geometry: GeometricData;
  terrain: TerrainData;
  roof: RoofData;
  zones: HeightZone[];
  tower?: TowerConfiguration;
  styleFeatures: StyleFeatures;
  facades: Facade[];
  scaffoldAccess: ScaffoldAccess[];
}

// ============================================
// SVG-Generierung
// ============================================

export type SvgType = 'grundriss' | 'fassadenansicht' | 'gebaeudesschnitt';

export interface SvgGenerationRequest {
  building: BuildingData;
  svgType: SvgType;
  options?: SvgOptions;
}

export interface SvgOptions {
  /** Welche Fassade zeigen (für Fassadenansicht) */
  facadeDirection?: 'N' | 'O' | 'S' | 'W';
  
  /** Schnittlinie (für Gebäudeschnitt) */
  sectionLine?: 'A-A' | 'B-B';
  
  /** Detailgrad */
  detailLevel?: 'low' | 'medium' | 'high';
}

export interface SvgGenerationResult {
  svg: string;
  metadata: {
    generatedAt: Date;
    buildingName: string;
    svgType: SvgType;
    dimensions: {
      width: number;
      height: number;
    };
  };
}

// ============================================
// Validierung
// ============================================

export interface ValidationError {
  field: string;
  message: string;
  severity: 'error' | 'warning';
}

export function validateBuildingData(data: BuildingData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Gebäudename darf nicht "RECHERCHIEREN" sein
  if (data.identification.buildingName === 'RECHERCHIEREN') {
    errors.push({
      field: 'identification.buildingName',
      message: 'Gebäudename muss recherchiert werden vor API-Call',
      severity: 'error'
    });
  }
  
  // Mindestens 1 Höhenzone
  if (data.zones.length === 0) {
    errors.push({
      field: 'zones',
      message: 'Mindestens eine Höhenzone muss definiert sein',
      severity: 'error'
    });
  }
  
  // Höhenzonen-Konsistenz prüfen
  const maxZoneHeight = Math.max(...data.zones.map(z => z.height));
  if (Math.abs(maxZoneHeight - data.geometry.roofHeight) > 1) {
    errors.push({
      field: 'zones',
      message: `Höchste Zone (${maxZoneHeight}m) weicht von Firsthöhe (${data.geometry.roofHeight}m) ab`,
      severity: 'warning'
    });
  }
  
  // Turm-Konsistenz prüfen
  if (data.tower) {
    const towerZones = data.zones.filter(z => z.type === 'turm');
    if (towerZones.length !== data.tower.count) {
      errors.push({
        field: 'tower',
        message: `Turmanzahl (${data.tower.count}) stimmt nicht mit Turm-Zonen (${towerZones.length}) überein`,
        severity: 'warning'
      });
    }
  }
  
  return errors;
}
