/**
 * Prompt Builder
 * Generiert optimierte Prompts für Claude API
 */

import { BuildingData, SvgType, SvgOptions, ValidationError, validateBuildingData } from './types';
import * as fs from 'fs';
import * as path from 'path';

// ============================================
// Template-Pfade
// ============================================

const TEMPLATE_DIR = path.join(__dirname, '..', 'templates');

const TEMPLATES = {
  system: path.join(TEMPLATE_DIR, 'system_prompt.md'),
  grundriss: path.join(TEMPLATE_DIR, 'grundriss.md'),
  fassadenansicht: path.join(TEMPLATE_DIR, 'fassadenansicht.md'),
  gebaeudesschnitt: path.join(TEMPLATE_DIR, 'gebaeudesschnitt.md'),
};

// ============================================
// Haupt-Funktion
// ============================================

export function buildPrompt(
  building: BuildingData,
  svgType: SvgType,
  options?: SvgOptions
): { systemPrompt: string; userPrompt: string; errors: ValidationError[] } {
  
  // 1. Validierung
  const errors = validateBuildingData(building);
  if (errors.some(e => e.severity === 'error')) {
    return {
      systemPrompt: '',
      userPrompt: '',
      errors
    };
  }
  
  // 2. System Prompt laden
  const systemPrompt = loadTemplate(TEMPLATES.system);
  
  // 3. SVG-spezifisches Template laden
  const svgTemplate = loadTemplate(TEMPLATES[svgType]);
  
  // 4. Gebäudedaten formatieren
  const buildingDataMarkdown = formatBuildingData(building, svgType, options);
  
  // 5. Template füllen
  const userPrompt = svgTemplate.replace('{{BUILDING_DATA}}', buildingDataMarkdown);
  
  return {
    systemPrompt,
    userPrompt,
    errors
  };
}

// ============================================
// Template laden
// ============================================

function loadTemplate(templatePath: string): string {
  try {
    return fs.readFileSync(templatePath, 'utf-8');
  } catch (error) {
    console.error(`Template nicht gefunden: ${templatePath}`);
    return '';
  }
}

// ============================================
// Gebäudedaten formatieren
// ============================================

function formatBuildingData(
  building: BuildingData,
  svgType: SvgType,
  options?: SvgOptions
): string {
  const lines: string[] = [];
  
  // Identifikation
  lines.push('## Gebäude-Identifikation');
  lines.push('');
  lines.push(`- **Adresse:** ${building.identification.address}`);
  lines.push(`- **EGID:** ${building.identification.egid}`);
  lines.push(`- **Koordinaten (LV95):** E ${building.identification.coordinates.e}, N ${building.identification.coordinates.n}`);
  lines.push(`- **Gebäudename:** ${building.identification.buildingName}`);
  lines.push(`- **Gebäudetyp:** ${building.identification.buildingType}`);
  lines.push(`- **Baustil:** ${building.identification.architecturalStyle}`);
  lines.push(`- **Baujahr:** ${building.identification.yearBuilt}`);
  if (building.identification.architect) {
    lines.push(`- **Architekt:** ${building.identification.architect}`);
  }
  lines.push('');
  
  // Geometrie
  lines.push('## Geometrische Basisdaten');
  lines.push('');
  lines.push(`- **Bounding Box:** ${building.geometry.boundingBox.length}m × ${building.geometry.boundingBox.width}m`);
  lines.push(`- **Grundfläche:** ${building.geometry.groundArea} m²`);
  lines.push(`- **Firsthöhe:** ${building.geometry.roofHeight} m`);
  lines.push(`- **Traufhöhe:** ${building.geometry.eaveHeight} m`);
  lines.push('');
  
  // Terrain
  lines.push('## Terrain');
  lines.push('');
  lines.push(`- **Terrain-Höhe:** ${building.terrain.terrainHeight} m ü.M.`);
  lines.push(`- **Referenzpunkt:** ${building.terrain.referencePoint} = ±0.00`);
  lines.push(`- **Hanglage:** ${building.terrain.isSloped ? 'Ja' : 'Nein (eben)'}`);
  lines.push('');
  
  // Höhenzonen (KRITISCH!)
  lines.push('## Höhenzonen');
  lines.push('');
  lines.push('| Zone | Typ | Höhe | Traufe | Eingerüstet |');
  lines.push('|------|-----|------|--------|-------------|');
  for (const zone of building.zones) {
    const scaffoldInfo = zone.isScaffolded 
      ? 'Ja' 
      : `Nein [${zone.scaffoldType}]`;
    lines.push(`| ${zone.name} | ${zone.type} | ${zone.height}m | ${zone.eaveHeight || '-'}m | ${scaffoldInfo} |`);
  }
  lines.push('');
  
  // Turmkonfiguration (falls vorhanden)
  if (building.tower) {
    lines.push('## Turmkonfiguration');
    lines.push('');
    lines.push(`- **Anzahl:** ${building.tower.count}`);
    lines.push(`- **Position:** ${building.tower.position}`);
    lines.push(`- **Form:** ${building.tower.form}`);
    lines.push(`- **Höhe:** ${building.tower.height}m`);
    lines.push('');
  }
  
  // Baustil-Merkmale
  lines.push('## Baustil-Merkmale');
  lines.push('');
  if (building.styleFeatures.buildingForm) {
    lines.push(`- **Bauform:** ${building.styleFeatures.buildingForm}`);
  }
  if (building.styleFeatures.windowType) {
    lines.push(`- **Fenster:** ${building.styleFeatures.windowType}`);
  }
  if (building.styleFeatures.portal) {
    lines.push(`- **Portal:** ${building.styleFeatures.portal}`);
  }
  if (building.styleFeatures.specialElements.length > 0) {
    lines.push(`- **Besondere Elemente:** ${building.styleFeatures.specialElements.join(', ')}`);
  }
  if (building.styleFeatures.material) {
    lines.push(`- **Material:** ${building.styleFeatures.material}`);
  }
  lines.push('');
  
  // SVG-spezifische Infos
  if (svgType === 'fassadenansicht' && options?.facadeDirection) {
    lines.push('## Fassaden-Auswahl');
    lines.push('');
    lines.push(`- **Dargestellte Fassade:** ${options.facadeDirection}`);
    lines.push('');
  }
  
  if (svgType === 'gebaeudesschnitt') {
    lines.push('## Schnitt-Information');
    lines.push('');
    lines.push(`- **Schnittlinie:** ${options?.sectionLine || 'A-A'}`);
    lines.push('');
  }
  
  return lines.join('\n');
}

// ============================================
// API-Aufruf Wrapper
// ============================================

export interface ClaudeApiConfig {
  apiKey: string;
  model: string;
  maxTokens: number;
}

export async function generateSvgWithClaude(
  building: BuildingData,
  svgType: SvgType,
  config: ClaudeApiConfig,
  options?: SvgOptions
): Promise<{ svg: string; errors: ValidationError[] }> {
  
  // 1. Prompt bauen
  const { systemPrompt, userPrompt, errors } = buildPrompt(building, svgType, options);
  
  if (errors.some(e => e.severity === 'error')) {
    return { svg: '', errors };
  }
  
  // 2. API-Aufruf (Beispiel mit fetch)
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: config.model,
        max_tokens: config.maxTokens,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: userPrompt
          }
        ]
      })
    });
    
    const data = await response.json();
    
    // 3. SVG aus Response extrahieren
    const svg = extractSvgFromResponse(data.content[0].text);
    
    // 4. SVG validieren
    const svgErrors = validateSvg(svg);
    
    return {
      svg,
      errors: [...errors, ...svgErrors]
    };
    
  } catch (error) {
    return {
      svg: '',
      errors: [{
        field: 'api',
        message: `API-Fehler: ${error}`,
        severity: 'error'
      }]
    };
  }
}

// ============================================
// SVG aus Response extrahieren
// ============================================

function extractSvgFromResponse(text: string): string {
  // SVG-Tag finden
  const svgMatch = text.match(/<svg[\s\S]*?<\/svg>/i);
  
  if (svgMatch) {
    return svgMatch[0];
  }
  
  // Falls kein SVG gefunden, ganzen Text zurückgeben
  return text;
}

// ============================================
// SVG Validierung
// ============================================

function validateSvg(svg: string): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Basis-Checks
  if (!svg.includes('<svg')) {
    errors.push({
      field: 'svg',
      message: 'Kein gültiges SVG-Tag gefunden',
      severity: 'error'
    });
    return errors;
  }
  
  if (!svg.includes('viewBox')) {
    errors.push({
      field: 'svg',
      message: 'viewBox-Attribut fehlt',
      severity: 'warning'
    });
  }
  
  // Pattern-Definitionen prüfen
  if (!svg.includes('id="hatch"')) {
    errors.push({
      field: 'svg',
      message: 'Schraffur-Pattern (#hatch) fehlt',
      severity: 'warning'
    });
  }
  
  // Geschlossene Tags prüfen
  if (!svg.includes('</svg>')) {
    errors.push({
      field: 'svg',
      message: 'SVG-Tag nicht geschlossen',
      severity: 'error'
    });
  }
  
  return errors;
}

// ============================================
// Batch-Generierung (alle 3 SVGs)
// ============================================

export async function generateAllSvgs(
  building: BuildingData,
  config: ClaudeApiConfig
): Promise<{
  grundriss: string;
  fassadenansicht: string;
  gebaeudesschnitt: string;
  errors: ValidationError[];
}> {
  
  const allErrors: ValidationError[] = [];
  
  // 1. Grundriss
  const grundrissResult = await generateSvgWithClaude(building, 'grundriss', config);
  allErrors.push(...grundrissResult.errors);
  
  // 2. Fassadenansicht
  const fassadeResult = await generateSvgWithClaude(building, 'fassadenansicht', config, {
    facadeDirection: 'W' // Default: Westfassade
  });
  allErrors.push(...fassadeResult.errors);
  
  // 3. Gebäudeschnitt
  const schnittResult = await generateSvgWithClaude(building, 'gebaeudesschnitt', config, {
    sectionLine: 'A-A'
  });
  allErrors.push(...schnittResult.errors);
  
  return {
    grundriss: grundrissResult.svg,
    fassadenansicht: fassadeResult.svg,
    gebaeudesschnitt: schnittResult.svg,
    errors: allErrors
  };
}

// ============================================
// Token-Schätzung
// ============================================

export function estimateTokens(text: string): number {
  // Grobe Schätzung: 1 Token ≈ 4 Zeichen
  return Math.ceil(text.length / 4);
}

export function compareTokenUsage(
  oldPrompts: { grundriss: string; fassade: string; schnitt: string },
  newPrompts: { system: string; grundriss: string; fassade: string; schnitt: string }
): {
  oldTotal: number;
  newTotal: number;
  savings: number;
  savingsPercent: number;
} {
  const oldTotal = 
    estimateTokens(oldPrompts.grundriss) +
    estimateTokens(oldPrompts.fassade) +
    estimateTokens(oldPrompts.schnitt);
  
  const newTotal =
    estimateTokens(newPrompts.system) + // System Prompt nur 1x
    estimateTokens(newPrompts.grundriss) +
    estimateTokens(newPrompts.fassade) +
    estimateTokens(newPrompts.schnitt);
  
  const savings = oldTotal - newTotal;
  const savingsPercent = Math.round((savings / oldTotal) * 100);
  
  return {
    oldTotal,
    newTotal,
    savings,
    savingsPercent
  };
}

// ============================================
// Export für Verwendung
// ============================================

export {
  buildPrompt,
  generateSvgWithClaude,
  generateAllSvgs,
  extractSvgFromResponse,
  validateSvg,
  estimateTokens,
  compareTokenUsage
};
