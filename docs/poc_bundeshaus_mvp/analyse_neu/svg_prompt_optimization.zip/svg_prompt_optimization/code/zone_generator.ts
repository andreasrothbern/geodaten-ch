/**
 * Höhenzonen-Generator
 * Automatische Generierung von Höhenzonen basierend auf Gebäudedaten
 */

import { 
  BuildingData, 
  HeightZone, 
  ZoneType, 
  BuildingType, 
  ArchitecturalStyle,
  TowerConfiguration 
} from './types';

// ============================================
// Haupt-Funktion
// ============================================

export function generateZones(
  buildingType: BuildingType,
  style: ArchitecturalStyle,
  roofHeight: number,
  eaveHeight: number,
  tower?: TowerConfiguration
): HeightZone[] {
  
  // Basierend auf Gebäudetyp die passende Strategie wählen
  switch (buildingType) {
    case 'Kirche':
    case 'Kathedrale':
      return generateChurchZones(style, roofHeight, eaveHeight, tower);
    
    case 'Rathaus':
      return generateTownHallZones(style, roofHeight, eaveHeight, tower);
    
    case 'Parlamentsgebäude':
      return generateParliamentZones(style, roofHeight, eaveHeight, tower);
    
    case 'Wohnhaus':
    case 'Geschäftshaus':
      return generateResidentialZones(roofHeight, eaveHeight);
    
    default:
      return generateDefaultZones(roofHeight, eaveHeight);
  }
}

// ============================================
// Kirchen-Zonen
// ============================================

function generateChurchZones(
  style: ArchitecturalStyle,
  roofHeight: number,
  eaveHeight: number,
  tower?: TowerConfiguration
): HeightZone[] {
  const zones: HeightZone[] = [];
  
  // Hauptschiff
  zones.push({
    name: 'Kirchenschiff',
    type: 'hauptgebaeude',
    height: calculateMainHeight(roofHeight, tower),
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Seitenschiffe (bei Basilika)
  if (style === 'Gotik' || style === 'Neugotik' || style === 'Romanik') {
    zones.push({
      name: 'Seitenschiff Nord',
      type: 'anbau',
      height: eaveHeight - 3,
      eaveHeight: eaveHeight - 5,
      isScaffolded: true,
      scaffoldType: 'Standard'
    });
    
    zones.push({
      name: 'Seitenschiff Süd',
      type: 'anbau',
      height: eaveHeight - 3,
      eaveHeight: eaveHeight - 5,
      isScaffolded: true,
      scaffoldType: 'Standard'
    });
  }
  
  // Turm
  if (tower) {
    const towerName = getTowerName(tower);
    zones.push({
      name: towerName,
      type: 'turm',
      height: tower.height,
      eaveHeight: calculateTowerEaveHeight(tower),
      isScaffolded: false,
      scaffoldType: 'Spezialgerüst',
      scaffoldReason: 'Höhe über 30m, Sonderkonstruktion erforderlich'
    });
    
    // Bei flankierenden Türmen: zweiten Turm hinzufügen
    if (tower.count === 2 && tower.position === 'flankierend') {
      zones.push({
        name: towerName.replace('Nord', 'Süd').replace('West', 'Ost'),
        type: 'turm',
        height: tower.height,
        eaveHeight: calculateTowerEaveHeight(tower),
        isScaffolded: false,
        scaffoldType: 'Spezialgerüst',
        scaffoldReason: 'Höhe über 30m, Sonderkonstruktion erforderlich'
      });
    }
  }
  
  // Chor
  zones.push({
    name: 'Chor',
    type: 'anbau',
    height: eaveHeight + 2,
    eaveHeight: eaveHeight - 2,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  return zones;
}

// ============================================
// Rathaus-Zonen
// ============================================

function generateTownHallZones(
  style: ArchitecturalStyle,
  roofHeight: number,
  eaveHeight: number,
  tower?: TowerConfiguration
): HeightZone[] {
  const zones: HeightZone[] = [];
  
  // Hauptgebäude
  zones.push({
    name: 'Hauptgebäude',
    type: 'hauptgebaeude',
    height: tower ? roofHeight * 0.4 : roofHeight,
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Arkaden (typisch für Rathäuser)
  if (style === 'Gotik' || style === 'Spätgotik' || style === 'Renaissance') {
    zones.push({
      name: 'Arkaden',
      type: 'arkade',
      height: 5,
      isScaffolded: true,
      scaffoldType: 'Standard'
    });
  }
  
  // Turm
  if (tower) {
    zones.push({
      name: 'Rathausturm',
      type: 'turm',
      height: tower.height,
      eaveHeight: tower.height * 0.7,
      isScaffolded: false,
      scaffoldType: 'Spezialgerüst',
      scaffoldReason: 'Historischer Turm, Sonderkonstruktion erforderlich'
    });
  }
  
  return zones;
}

// ============================================
// Parlament-Zonen (Bundeshaus-Typ)
// ============================================

function generateParliamentZones(
  style: ArchitecturalStyle,
  roofHeight: number,
  eaveHeight: number,
  tower?: TowerConfiguration
): HeightZone[] {
  const zones: HeightZone[] = [];
  
  const wingHeight = eaveHeight + 5;
  const connectionHeight = eaveHeight;
  
  // Westflügel
  zones.push({
    name: 'Hauptgebäude West',
    type: 'hauptgebaeude',
    height: wingHeight,
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Ostflügel
  zones.push({
    name: 'Hauptgebäude Ost',
    type: 'hauptgebaeude',
    height: wingHeight,
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Verbindungsgänge
  zones.push({
    name: 'Verbindungsgang West',
    type: 'verbindung',
    height: connectionHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  zones.push({
    name: 'Verbindungsgang Ost',
    type: 'verbindung',
    height: connectionHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Zentralbau
  zones.push({
    name: 'Zentralbau',
    type: 'hauptgebaeude',
    height: wingHeight,
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  });
  
  // Kuppel (falls vorhanden)
  if (tower && tower.form === 'Kuppel') {
    zones.push({
      name: 'Kuppel',
      type: 'kuppel',
      height: tower.height,
      isScaffolded: false,
      scaffoldType: 'Spezialgerüst',
      scaffoldReason: 'Kuppelform erfordert Spezialkonstruktion'
    });
  }
  
  return zones;
}

// ============================================
// Wohnhaus-Zonen
// ============================================

function generateResidentialZones(
  roofHeight: number,
  eaveHeight: number
): HeightZone[] {
  return [{
    name: 'Hauptgebäude',
    type: 'hauptgebaeude',
    height: roofHeight,
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  }];
}

// ============================================
// Standard-Zonen
// ============================================

function generateDefaultZones(
  roofHeight: number,
  eaveHeight: number
): HeightZone[] {
  return [{
    name: 'Hauptgebäude',
    type: 'hauptgebaeude',
    height: roofHeight,
    eaveHeight: eaveHeight,
    isScaffolded: true,
    scaffoldType: 'Standard'
  }];
}

// ============================================
// Hilfsfunktionen
// ============================================

function calculateMainHeight(roofHeight: number, tower?: TowerConfiguration): number {
  if (!tower) return roofHeight;
  // Hauptgebäude ist niedriger als Turm
  return Math.min(roofHeight * 0.5, tower.height * 0.4);
}

function getTowerName(tower: TowerConfiguration): string {
  switch (tower.position) {
    case 'zentral':
      return 'Westturm';
    case 'flankierend':
      return 'Nordturm';
    case 'ecke':
      return 'Eckturm';
    default:
      return 'Turm';
  }
}

function calculateTowerEaveHeight(tower: TowerConfiguration): number {
  // Turmschaft endet etwa bei 70% der Gesamthöhe
  return tower.height * 0.7;
}

// ============================================
// Turm-Erkennung aus Höhendifferenz
// ============================================

export function detectTower(
  roofHeight: number,
  eaveHeight: number,
  buildingType: BuildingType
): TowerConfiguration | undefined {
  
  const heightDifference = roofHeight - eaveHeight;
  
  // Turm erkennbar wenn Höhendifferenz > 15m
  if (heightDifference > 15) {
    // Turmform basierend auf Gebäudetyp
    let form: TowerConfiguration['form'] = 'Spitzhelm';
    let position: TowerConfiguration['position'] = 'zentral';
    
    if (buildingType === 'Parlamentsgebäude') {
      form = 'Kuppel';
    } else if (buildingType === 'Kirche' && heightDifference > 40) {
      // Sehr hoher Turm bei Kirchen oft Doppelturm
      // ABER: Muss recherchiert werden!
      position = 'zentral'; // Default, muss validiert werden
    }
    
    return {
      count: 1, // Default, muss recherchiert werden!
      position,
      form,
      height: roofHeight,
      scaffoldType: 'Spezialgerüst'
    };
  }
  
  return undefined;
}

// ============================================
// Validierung
// ============================================

export function validateZones(zones: HeightZone[], roofHeight: number): string[] {
  const warnings: string[] = [];
  
  // Mindestens eine Zone
  if (zones.length === 0) {
    warnings.push('Keine Höhenzonen definiert');
  }
  
  // Höchste Zone sollte Firsthöhe entsprechen
  const maxHeight = Math.max(...zones.map(z => z.height));
  if (Math.abs(maxHeight - roofHeight) > 2) {
    warnings.push(`Höchste Zone (${maxHeight}m) weicht von Firsthöhe (${roofHeight}m) ab`);
  }
  
  // Turm-Zonen sollten Spezialgerüst haben
  zones.filter(z => z.type === 'turm' || z.type === 'kuppel').forEach(z => {
    if (z.isScaffolded && z.height > 30) {
      warnings.push(`Zone "${z.name}" (${z.height}m) sollte Spezialgerüst haben`);
    }
  });
  
  return warnings;
}
