# SVG-Analyse: Kirche St. Peter und Paul

## Inhalt des Pakets

```
kirche_st_peter_paul_analyse/
├── README.md                  # Diese Datei
├── vergleich.md               # Detaillierter SVG-Vergleich
├── verbesserungen.md          # Konkrete Prompt-Verbesserungen
├── prompt_original.md         # Originaler SVG-Prompt
│
├── grundriss_api.svg          # Von Claude API generiert
├── ansicht_api.svg            # Von Claude API generiert
├── schnitt_api.svg            # Von Claude API generiert
│
├── grundriss_claude.svg       # Von Claude.ai generiert (besser!)
├── ansicht_claude.svg         # Von Claude.ai generiert
└── schnitt_claude.svg         # Von Claude.ai generiert
```

## Gebäude-Information

| Attribut | Wert |
|----------|------|
| **Adresse** | Rathausgasse 2, 3011 Bern |
| **Name** | Kirche St. Peter und Paul |
| **EGID** | 191821074 |
| **Baujahr** | 1864 |
| **Baustil** | Neugotik |
| **Komplexität** | COMPLEX (4 Zonen) |

## Zonen

| Zone | Typ | Höhe |
|------|-----|------|
| Westturm | turm | 54.6m |
| Kirchenschiff | hauptgebaeude | 25.0m |
| Chor | anbau | 18.0m |
| Seitenschiffe | anbau | 12.0m |

## Ergebnis-Übersicht

| SVG | API-Qualität | Claude.ai | Gewinner |
|-----|--------------|-----------|----------|
| Grundriss | 40% ❌ | 95% ✅ | **Claude.ai** |
| Ansicht | 80% ✅ | 90% ✅ | Claude.ai |
| Schnitt | 90% ✅ | 92% ✅ | Gleich |

## Hauptprobleme identifiziert

1. **Grundriss-Generator inkompatibel** (P0)
   - Falsches ViewBox (600×500 statt 700×480)
   - Keine Zonen-Darstellung
   - Interaktives Format statt technisch

2. **Zonen-Validierung fehlerhaft** (P0)
   - Warnt bei Kirchenschiffen, die niedriger als Turm sind
   - Das ist bei Kirchen normal!

3. **Fehlende Stil-Hinweise** (P1)
   - Neugotik wird nicht visualisiert
   - Keine Spitzbögen im API-SVG

## Nächste Schritte

Siehe `verbesserungen.md` für konkrete Code-Änderungen.

---

*Generiert: 30.12.2025*
*Projekt: geodaten-ch*
